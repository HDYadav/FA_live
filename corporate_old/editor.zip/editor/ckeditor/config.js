CKEDITOR.editorConfig = function( config ) {
	config.language = 'es';
	config.uiColor = 'aqua';
	config.height = 300;
	config.toolbarCanCollapse = true;
};